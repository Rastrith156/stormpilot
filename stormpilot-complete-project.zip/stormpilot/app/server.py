import json
import os
import threading
import time
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

COUNTS = Counter()
LOCK = threading.Lock()
START = time.monotonic()

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        status = 200
        content_type = 'application/json'
        if path in ('/healthz', '/readyz'):
            body = {'status': 'ok'}
        elif path == '/':
            body = {'project': 'StormPilot', 'mission': 'Resilient drone dispatch',
                    'instance': os.getenv('HOSTNAME', 'local'),
                    'version': os.getenv('APP_VERSION', 'dev')}
        elif path == '/dispatch':
            # Deterministic CPU work enables an observable CPU autoscaling demo.
            value = 1
            for i in range(100000):
                value = (value * 31 + i) % 1000000007
            body = {'status': 'dispatched', 'route_checksum': value}
        elif path == '/metrics':
            content_type = 'text/plain; version=0.0.4'
            with LOCK:
                snapshot = list(COUNTS.items())
            lines = ['# HELP stormpilot_requests_total Business HTTP requests.',
                     '# TYPE stormpilot_requests_total counter']
            for (route, code), count in sorted(snapshot):
                lines.append(f'stormpilot_requests_total{{route="{route}",status="{code}"}} {count}')
            lines += ['# HELP stormpilot_uptime_seconds Process uptime.',
                      '# TYPE stormpilot_uptime_seconds gauge',
                      f'stormpilot_uptime_seconds {time.monotonic() - START:.3f}']
            body = '\n'.join(lines) + '\n'
        else:
            status = 404
            body = {'error': 'not found'}
        if path not in ('/healthz', '/readyz', '/metrics'):
            route = path if path in ('/', '/dispatch') else 'other'
            with LOCK:
                COUNTS[(route, status)] += 1
        payload = (json.dumps(body) if isinstance(body, dict) else body).encode()
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, fmt, *args):
        print(json.dumps({'event': 'http', 'message': fmt % args}), flush=True)

if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', int(os.getenv('PORT', '8080'))), Handler).serve_forever()
